"""Build the English three-page conference-style PDF and Chinese study guide.
Requires reportlab and the completed study.py/summarize.py outputs.
"""
from pathlib import Path
import json,csv,html,shutil,hashlib
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph,Table,TableStyle,Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import reportlab
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results';D=ROOT/'deliverables';D.mkdir(exist_ok=True)
S=json.loads((R/'summary.json').read_text());M={(r['scheme'],r['model']):r for r in S['metrics']}
def metric(s,m,k='mae'):return M[(s,m)][k]
G='within_shape_context_holdout';H='leave_one_shape_out'
refs=[
('City Syntax Lab. Buildings.sg: open building archetypes and EnergyPlus templates. Office model 06_Office_SGP_2025_V5.idf. Accessed 2026-10-03.','https://github.com/City-Syntax/buildings.sg'),
('EnergyPlus. Version 24.2 Input Output Reference: ZoneHVAC:IdealLoadsAirSystem.','https://bigladdersoftware.com/epx/docs/24-2/input-output-reference/group-zone-forced-air-units.html#zonehvacidealloadsairsystem'),
('Markarian, E., et al. (2024, online). Informing building retrofits at low computational costs: a multi-objective optimisation using machine learning surrogates of building performance simulation models. Journal of Building Performance Simulation.','https://doi.org/10.1080/19401493.2024.2384487'),
('Thrampoulidis, E., Mavromatidis, G., Lucchi, A., and Orehounig, K. (2021). A machine learning-based surrogate model to approximate optimal building retrofit solutions. Applied Energy, 281, 116024.','https://doi.org/10.1016/j.apenergy.2020.116024'),
('Ladybug Tools. Singapore IWEC weather file, WMO 486980, UWG repository.','https://github.com/ladybug-tools/uwg/blob/master/resources/SGP_Singapore.486980_IWEC.epw'),
('Scikit-learn. Cross-validation: evaluating estimator performance; grouped validation.','https://scikit-learn.org/stable/modules/cross_validation.html')]
(ROOT/'references.json').write_text(json.dumps([{'id':i+1,'citation':a,'url':b} for i,(a,b) in enumerate(refs)],indent=2),encoding='utf8')
P=lambda x:('p',x);T=lambda x:('h',x);SM=lambda x:('small',x);FIG=lambda f,c:('fig',f,c);TAB=lambda r:('table',r)
title='Transferability of Window Solar-Control Strategies across Singapore Office Plan Shapes'
abstract=(f'This interim study tests whether window-strategy effects and machine-learning predictions transfer between simplified office plan shapes. An open Buildings.sg template is adapted into three 900 m² intermediate-floor models. A factorial experiment combines three aspect ratios, four orientations, three window-to-wall ratios and four strategies, producing 144 annual EnergyPlus simulations. The outcome is ideal-loads cooling thermal demand, not measured electricity. Polynomial Ridge and random forest are assessed using grouped context holdout and leave-one-shape-out validation. Shape-held-out mean absolute errors are {metric(H,"ridge"):.2f} and {metric(H,"forest"):.2f} kWh thermal/m²/year, compared with {metric(H,"strategy_mean"):.2f} for a strategy-mean baseline. Lower-SHGC glass outperforms the specified overhang in all 36 contexts, so zero strategy-selection loss is uninformative. The interim contribution is a reproducible transfer test and an explicit account of where this small controlled experiment cannot support design generalisation.')
columns=[
 [T('Abstract'),P(abstract),SM('<b>Keywords</b> office windows; cooling demand; surrogate model; shape transfer; grouped validation'),
 T('1 Introduction'),P('Early design studies often evaluate window options on one reference geometry. A strategy may have different demand-reduction magnitudes on another shape, while a surrogate that predicts familiar cases well may perform poorly on an unseen shape. These two issues should be examined separately. This project asks whether the effects of glazing and overhangs transfer across rectangular office plans, and whether simple machine-learning models predict demand under an explicit shape holdout.'),
 P('The practical aim is to indicate when a quick model estimate can support preliminary cooling-demand comparisons and when another simulation is warranted. The study does not estimate retrofit payback, whole-building electricity, daylight quality or real-building causal savings.')],
 [T('2 Related work'),P('Markarian et al. [3] couple building-performance surrogates with multi-objective retrofit optimisation. Thrampoulidis et al. [4] approximate retrofit solutions using neural-network surrogates. These studies establish that simulation-based surrogate methods already exist; using EnergyPlus and machine learning is not itself a new contribution. This course project instead provides a bounded, reproducible comparison of familiar-context and withheld-shape prediction, alongside a check of whether strategy selection is genuinely discriminating.'),
 T('3 Model and experimental data'),P('The original Buildings.sg office IDF [1] contains five zones in a 10 m by 10 m shoebox. We preserve its zone topology but remap coordinates to a 900 m² rectangular floor with a fixed 3 m perimeter-zone depth and 3 m height. Aspect ratios 1, 2 and 4 yield dimensions 30×30, 42.43×21.21 and 60×15 m. Roof and floor become adiabatic to represent an intermediate floor. Original fixed interzone mixing is removed; no bulk interzone airflow is imposed.'),
 P('Zone volumes and areas are recalculated. Each wall has a centred window with width and height scaled to achieve its prescribed area ratio. Horizontal overhangs extend from each window head and span that window width. Shading rotates with the building. The adapted models are controlled research prototypes, not calibrated replicas of occupied buildings.'),
 TAB([['Factor','Levels'],['Aspect ratio','1, 2, 4'],['Rotation','0°, 45°, 90°, 135°'],['Window/wall area','20%, 40%, 60%'],['Strategy','baseline; glass; shade; combined']]),
 SM('Table 1. Full factorial design: 3×4×3×4 = 144 runs; 36 contexts with four paired strategies.')],
 [T('3.1 Controlled assumptions'),P('Baseline glazing uses SHGC 0.60; the glass option uses 0.30. The shade option adds a 0.60 m opaque overhang; combined applies both changes. Glazing U-value stays at 1.6 W/(m² K), and visible transmittance at 0.60. These are hypothetical controlled options, not priced commercial products. Lighting has no daylight-responsive control.'),
 P('The original 26°C cooling setpoint, 9 W/m² lighting, 22 W/m² equipment and 0.047501 persons/m² design density are retained. Weekday occupancy fractions from 09:00 to 18:00 are inherited; weekends are unoccupied. Outdoor air is explicitly changed from the original 6 ACH to a study assumption of 0.6 ACH, scheduled with occupancy. Heat recovery is disabled. These choices require later sensitivity testing and are not asserted to be a compliance standard.'),
 P('Ideal-loads systems [2] use unlimited capacity, retaining the template humidity controls. Singapore IWEC weather [5] is a typical-weather input, not observed 2024 weather. The run uses the template non-leap 2006 calendar. No urban obstruction, infiltration or occupant-behaviour variation is added.'),
 T('3.2 Outcomes and quality checks'),P('Hourly Zone Ideal Loads Supply Air Total Cooling Energy is summed across the five zones over 8,760 hours. It includes supply-air conditioning demand under the stated ventilation and humidity controls. Annual cooling intensity is q = sum(Q) / (3.6e6 A), with Q in joules and A = 900 m². Reduction is 100(q_baseline − q_option)/q_baseline within the same context. Hourly peak demand is also retained as a secondary output.'),
 P('All 144 runs passed floor-area, WWR and internal-face matching checks and completed without severe errors. Six warnings per run concern inherited schedule-limit metadata and unused constructions; these are disclosed, not suppressed. Numerical checks establish execution consistency, not empirical validation.')],
 [T('4 Surrogate modelling and validation'),P('Predictors are log aspect ratio, wall-to-floor-area ratio, sin(2 theta), cos(2 theta), WWR, SHGC and overhang depth. The 180-degree orientation encoding is appropriate to these rectangular plans with identical opposite facades. A degree-two polynomial Ridge model uses training-fold scaling and alpha = 10. Random forest uses 200 trees, maximum depth 6, minimum leaf size 3 and seed 2026. Settings are fixed without tuning. Training-mean and strategy-mean predictors provide simple baselines.'),
 P('Six-fold grouped validation holds out complete shape–orientation–WWR contexts, keeping all four strategies together. Square-plan rotations differing by 90 degrees are grouped together to reduce leakage through symmetry. Leave-one-shape-out validation trains on 96 runs and tests on the remaining 48. The middle aspect ratio tests interpolation along this shape family; endpoint holdouts test extrapolation. MAE, RMSE and R² are computed from the pooled held-out predictions [6].'),
 P('For a secondary decision check, the surrogate chooses between the two single interventions: glass and shade. Thermal selection loss is q(chosen) − min[q(glass), q(shade)], evaluated using withheld simulations. This is not cost optimisation. Combined is reported separately so that an unconstrained strongest package does not trivialise the comparison. Ties are resolved deterministically; a constant model therefore defaults to glass.'),
 T('5 Preliminary results'),
 FIG('cooling_comparison.png','Figure 1. Paired annual cooling demand at 0° rotation and WWR 40%. Results are simulations of adapted intermediate floors.'),
 P(f'Across all contexts, glass reduces demand by {S["strategy_reductions"]["glass"]["min_pct"]:.1f}–{S["strategy_reductions"]["glass"]["max_pct"]:.1f}%; shade by {S["strategy_reductions"]["shade"]["min_pct"]:.1f}–{S["strategy_reductions"]["shade"]["max_pct"]:.1f}%; combined by {S["strategy_reductions"]["combined"]["min_pct"]:.1f}–{S["strategy_reductions"]["combined"]["max_pct"]:.1f}%. These ranges pool changes in shape, orientation and WWR and must not be attributed to shape alone.')],
 [FIG('validation_mae.png','Figure 2. Pooled held-out MAE under two validation schemes. The same simulated outcomes and fixed model settings are used.'),
 TAB([['Model','Context MAE','Shape MAE']]+[[{'mean':'Mean','strategy_mean':'Strategy mean','ridge':'Ridge','forest':'Forest'}[m],f'{metric(G,m):.2f}',f'{metric(H,m):.2f}'] for m in ['mean','strategy_mean','ridge','forest']]),
 SM('Table 2. Errors in kWh thermal/m²/year. Fold spread is not a population confidence interval.'),
 P('Prediction must also be inspected by withheld shape rather than only in aggregate. A low overall error does not validate transfer beyond the tested three rectangles. No algorithm is selected solely because of a small difference in aggregate error.'),
 P(f'Glass has lower demand than the specified overhang in all {S["glass_beats_shade_contexts"]} contexts. Every tested model has zero thermal selection loss, including the constant predictor whose tie rule defaults to glass. Consequently, the present binary decision test does not demonstrate useful AI decision-making or a ranking reversal. The continuous demand-prediction errors are more informative at this stage.'),
 T('6 Limitations and next stage'),P('Only three equal-area rectangular intermediate floors, one weather file and one operation scenario are represented. Simulated rows are not independent observations of actual buildings. Roof exposure, urban shading, facade-specific windows, daylight, prices and detailed HVAC electricity are outside scope. The small grid is fast to simulate, so no practical speed advantage is claimed from training a surrogate.'),
 P('The next stage will predefine additional intermediate aspect ratios and a second floor area, then use them as untouched external simulation tests. Ventilation and schedule sensitivities will assess whether demand reductions persist. Continuous reduction-prediction error will be prioritised over the currently degenerate two-option selection metric. Any expanded strategy menu will be declared before new simulations, rather than chosen to manufacture ranking reversals.')],
 [T('7 Interim conclusion'),P('The workflow produces reproducible window-strategy data and explicitly tests withheld shapes. Under the controlled assumptions, both learned models improve demand prediction over simple baselines. However, stable glass-versus-shade ordering makes selection accuracy non-discriminating. The justified contribution is a transparent assessment of prediction transfer within a restricted shape family, not a universal facade recommendation.'),
 T('Reproducibility'),P('The submission includes original IDF and weather inputs with SHA256 hashes, the 144-row design matrix, generated models, simulated outcomes, grouped predictions, error metrics, source code and a Chinese execution guide. EnergyPlus 24.2 is required to regenerate outcomes. Existing CSV files support analysis without rerunning simulations. The main commands are prepare, run --scope full, analyze, and summarize.py.'),
 T('References')]+[SM(f'[{i+1}] {html.escape(a)}<br/><link href="{b}" color="#15546a">{html.escape(b)}</link>') for i,(a,b) in enumerate(refs)]
]
fontdir=Path(reportlab.__file__).parent/'fonts'
pdfmetrics.registerFont(TTFont('Vera',str(fontdir/'Vera.ttf')));pdfmetrics.registerFont(TTFont('VeraBold',str(fontdir/'VeraBd.ttf')))
pdfmetrics.registerFontFamily('Vera',normal='Vera',bold='VeraBold',italic='Vera',boldItalic='VeraBold')
styles={'p':ParagraphStyle('p',fontName='Vera',fontSize=8.7,leading=11.4,spaceAfter=7),
 'h':ParagraphStyle('h',fontName='VeraBold',fontSize=10.7,leading=13.5,spaceBefore=5,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='Vera',fontSize=7.2,leading=9.5,spaceAfter=6)}
c=canvas.Canvas(str(D/'interim_paper.pdf'),pagesize=(595.276,841.89));c.setTitle(title)
markdown=['# '+title,'BPS5231 Interim Study | 3 October 2026','']
for page in range(3):
    c.setFont('Vera',8);c.drawString(35,814,'BPS5231  |  AI for Sustainable Building Design  |  Interim study');c.drawRightString(560,24,str(page+1))
    top=788
    if page==0:
        heading=Paragraph(title,ParagraphStyle('title',fontName='VeraBold',fontSize=16,leading=20))
        _,h=heading.wrap(525,90);heading.drawOn(c,35,top-h);top-=h+17
    for col in range(2):
        x=35+col*271;y=top;width=254
        for block in columns[2*page+col]:
            kind=block[0]
            if kind in styles:
                para=Paragraph(block[1],styles[kind]);_,h=para.wrap(width,900);y-=styles[kind].spaceBefore
                if y-h<40:raise RuntimeError(f'Paper overflow page {page+1} col {col+1}: {block[1][:60]} at {y-h}')
                para.drawOn(c,x,y-h);y-=h+styles[kind].spaceAfter
                markdown+= [('## ' if kind=='h' else '')+re_strip(block[1]) if False else ('## ' if kind=='h' else '')+block[1],'']
            elif kind=='fig':
                im=Image(str(R/'figures'/block[1]),width=width,height=108);y-=108;im.drawOn(c,x,y);y-=6
                cap=Paragraph(block[2],styles['small']);_,h=cap.wrap(width,80);y-=h;cap.drawOn(c,x,y);y-=8
                markdown+=['![Figure](../results/figures/'+block[1]+')',block[2],'']
            else:
                cells=[[Paragraph(html.escape(str(v)),styles['small']) for v in row] for row in block[1]]
                table=Table(cells,colWidths=[width/len(cells[0])]*len(cells[0]));table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e7eef0')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
                _,h=table.wrap(width,800);y-=h;table.drawOn(c,x,y);y-=9
                markdown+=[' | '.join(row) for row in block[1]]+['']
        if y<40:raise RuntimeError(f'Paper overflow p{page+1} col{col+1}')
    c.showPage()
c.save();(D/'interim_paper_editable.md').write_text('\n'.join(markdown),encoding='utf8')
print('Created three-page paper and editable Markdown source.')
