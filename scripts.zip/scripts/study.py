"""Reproducible office-window experiment. Python stdlib; analysis adds sklearn/numpy.
Commands: prepare; run --energyplus PATH [--scope pilot|full]; analyze.
The pilot is 12 real annual simulations, NOT empirical building observations.
"""
from pathlib import Path
import argparse,copy,csv,hashlib,json,math,re,sqlite3,subprocess,concurrent.futures,time
ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw'; INPUTS=ROOT/'data/idf'; RESULTS=ROOT/'results'
QNAME='Zone Ideal Loads Supply Air Total Cooling Energy'
STRATEGIES={'baseline':(.60,0.),'glass':(.30,0.),'shade':(.60,.60),'combined':(.30,.60)}
def read_idf(path):
    text=re.sub(r'!.*','',path.read_text(encoding='utf-8-sig'))
    return [[v.strip() for v in block.split(',')] for block in text.split(';') if block.strip()]
def write_idf(path,objs):
    path.write_text('\n\n'.join(',\n  '.join(o)+';' for o in objs),encoding='utf8')
def vertices(o):
    start=12 if o[0]=='BuildingSurface:Detailed' else 10
    return [[float(v) for v in o[k:k+3]] for k in range(start,len(o),3)]
def set_vertices(o,vs):
    start=12 if o[0]=='BuildingSurface:Detailed' else 10
    o[start-1]=str(len(vs));o[start:]=[f'{v:.9f}' for p in vs for v in p]
def area(vs):
    c=[0.,0.,0.]
    for a,b in zip(vs,vs[1:]+vs[:1]):
        c[0]+=a[1]*b[2]-a[2]*b[1];c[1]+=a[2]*b[0]-a[0]*b[2];c[2]+=a[0]*b[1]-a[1]*b[0]
    return math.sqrt(sum(x*x for x in c))/2
def remap(v,dim):
    # Preserve 3 m perimeter-zone depth, unlike uniform affine scaling.
    if v<=1:return v*3
    if v>=9:return dim-(10-v)*3
    return 3+(v-1)*(dim-6)/8
def generate(base,row):
    L,W=row['length_m'],row['width_m'];objs=copy.deepcopy(base)
    # Simplified independent thermal zones: remove original fixed-flow mixing.
    objs=[o for o in objs if o[0] not in ['ZoneMixing','Output:Variable','Output:Meter','Output:SQLite','SizingPeriod:DesignDay'] and not o[0].startswith('LifeCycleCost:')]
    for o in objs:
        typ=o[0]
        if typ=='Building':o[2]=str(row['orientation_deg'])
        elif typ=='Site:Location':o[1:]=['Singapore IWEC','1.37','103.98','8','16']
        elif typ=='Zone':o[9]='Autocalculate';o[10]='Autocalculate'
        elif typ=='BuildingSurface:Detailed':
            set_vertices(o,[[remap(x,L),remap(y,W),z] for x,y,z in vertices(o)])
            if o[2] in ['Floor','Roof']:
                o[6:10]=['Adiabatic','','NoSun','NoWind']
        elif typ=='WindowMaterial:SimpleGlazingSystem':
            o[2:5]=['1.6',str(row['shgc']),'.6']
        elif typ=='ZoneHVAC:IdealLoadsAirSystem':
            o[10:16]=['NoLimit','','','NoLimit','','']
            o[25:28]=['None','0','0'] # Explicit study assumption: no heat recovery.
        elif typ=='DesignSpecification:OutdoorAir':
            o[2:8]=['Sum','0','0','0','.6','Building Occupancy']
        elif typ=='SimulationControl':o[1:]=['No','No','No','No','Yes','No']
    walls={o[1]:o for o in objs if o[0]=='BuildingSurface:Detailed'}
    shades=[];window_area=0;wall_area=0
    for o in objs:
        if o[0]!='FenestrationSurface:Detailed':continue
        wall=walls[o[4]];vs=vertices(wall);center=[sum(v[i] for v in vs)/4 for i in range(3)]
        # Centre window, both width and height scaled sqrt(WWR).
        factor=math.sqrt(row['wwr']);wv=[[center[i]+factor*(v[i]-center[i]) for i in range(3)] for v in vs]
        set_vertices(o,wv);window_area+=area(wv);wall_area+=area(vs)
        if row['overhang_m']:
            top=sorted(wv,key=lambda v:v[2],reverse=True)[:2]
            a,b=top;cx,cy=center[:2]
            if abs(cx)<1e-6:normal=(-1,0)
            elif abs(cx-L)<1e-6:normal=(1,0)
            elif abs(cy)<1e-6:normal=(0,-1)
            else:normal=(0,1)
            d=row['overhang_m'];out=lambda v:[v[0]+normal[0]*d,v[1]+normal[1]*d,v[2]]
            pts=[a,b,out(b),out(a)]
            shades.append(['Shading:Zone:Detailed',o[1]+'_overhang',wall[1],'','4']+[f'{v:.9f}' for p in pts for v in p])
    objs+=shades+[['Output:Variable','*',QNAME,'Hourly'],['Output:SQLite','SimpleAndTabular']]
    floors=[o for o in objs if o[0]=='BuildingSurface:Detailed' and o[2]=='Floor']
    floor_area=sum(area(vertices(o)) for o in floors)
    assert abs(floor_area-900)<1e-5
    assert abs(window_area/wall_area-row['wwr'])<1e-8
    # Every internal face must still have its matching counterpart geometry.
    for wall in walls.values():
        if wall[6]=='Surface':
            other=walls[wall[7]]
            assert sorted(vertices(wall))==sorted(vertices(other))
    return objs,{'floor_area_m2':floor_area,'wall_area_m2':wall_area,'window_area_m2':window_area,'verified_wwr':window_area/wall_area,'zones':len(floors),'overhangs':len(shades)}
def save_csv(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def prepare():
    INPUTS.mkdir(parents=True,exist_ok=True);RESULTS.mkdir(parents=True,exist_ok=True)
    base=read_idf(RAW/'office_original.idf');rows=[];qa=[]
    for ratio in [1,2,4]:
        for orientation in [0,45,90,135]:
            for wwr in [.2,.4,.6]:
                for strategy,(shgc,depth) in STRATEGIES.items():
                    row={'case_id':f'r{ratio}_o{orientation:03d}_w{int(wwr*100):02d}_{strategy}',
                         'aspect_ratio':ratio,'length_m':math.sqrt(900*ratio),'width_m':math.sqrt(900/ratio),
                         'orientation_deg':orientation,'wwr':wwr,'strategy':strategy,'shgc':shgc,'overhang_m':depth,
                         'floor_area_m2':900,'pilot':int(orientation==0 and wwr==.4)}
                    objects,checks=generate(base,row);write_idf(INPUTS/(row['case_id']+'.idf'),objects)
                    rows.append(row);qa.append({'case_id':row['case_id'],**checks})
    save_csv(ROOT/'data/design_matrix.csv',rows);save_csv(RESULTS/'geometry_checks.csv',qa)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in RAW.iterdir() if p.is_file()}
    (RESULTS/'input_hashes.json').write_text(json.dumps(hashes,indent=2))
    print(f'Prepared {len(rows)} cases; pilot={sum(r["pilot"] for r in rows)}. Geometry checks passed.')
def one_run(row,exe):
    folder=RESULTS/'runs'/row['case_id'];folder.mkdir(parents=True,exist_ok=True)
    cache=folder/'record.json';model=INPUTS/(row['case_id']+'.idf');weather=RAW/'singapore_iwec.epw'
    signature=hashlib.sha256(model.read_bytes()+weather.read_bytes()).hexdigest()
    if cache.exists():
        prior=json.loads(cache.read_text())
        if prior.get('input_hash')==signature:return prior
    start=time.perf_counter()
    proc=subprocess.run([str(exe),'-w',str(weather),'-d',str(folder),str(model)],capture_output=True,text=True,timeout=300)
    (folder/'console.txt').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf8')
    err=(folder/'eplusout.err').read_text(errors='replace') if (folder/'eplusout.err').exists() else ''
    if proc.returncode or '** Severe **' in err or '**  Fatal  **' in err:raise RuntimeError(f'{row["case_id"]}: see {folder}/eplusout.err')
    with sqlite3.connect(folder/'eplusout.sql') as db:
        hours=db.execute('''SELECT r.TimeIndex,SUM(r.Value),COUNT(*) FROM ReportData r
        JOIN ReportDataDictionary d ON r.ReportDataDictionaryIndex=d.ReportDataDictionaryIndex
        JOIN Time t ON r.TimeIndex=t.TimeIndex JOIN EnvironmentPeriods e ON t.EnvironmentPeriodIndex=e.EnvironmentPeriodIndex
        WHERE d.Name=? AND d.ReportingFrequency='Hourly' AND COALESCE(t.WarmupFlag,0)=0 AND e.EnvironmentType=3
        GROUP BY r.TimeIndex ORDER BY r.TimeIndex''',(QNAME,)).fetchall()
    assert len(hours)==8760,(row['case_id'],len(hours))
    assert all(n==5 for _,_,n in hours),'Missing/duplicate zone outputs'
    annual=sum(v for _,v,_ in hours)/3.6e6
    rec={**row,'cooling_kwh_th':annual,'cooling_kwh_th_m2':annual/900,
         'peak_hourly_cooling_kw_th':max(v for _,v,_ in hours)/3.6e6,'hours':8760,
         'warnings':err.count('** Warning **'),'runtime_seconds':time.perf_counter()-start,'input_hash':signature}
    cache.write_text(json.dumps(rec,indent=2));return rec
def run(exe,scope,workers):
    exe=Path(exe).resolve();assert exe.exists(),exe
    version=subprocess.check_output([str(exe),'--version'],text=True).strip()
    if '24.2' not in version:raise RuntimeError('This IDF pipeline requires EnergyPlus 24.2')
    rows=read_csv(ROOT/'data/design_matrix.csv')
    if scope=='pilot':rows=[r for r in rows if r['pilot']=='1']
    records=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        pending={pool.submit(one_run,r,exe):r for r in rows}
        for future in concurrent.futures.as_completed(pending):
            r=future.result();records.append(r);print(r['case_id'],round(r['cooling_kwh_th_m2'],3),flush=True)
    records.sort(key=lambda r:r['case_id']);save_csv(RESULTS/(scope+'_results.csv'),records)
    (RESULTS/(scope+'_provenance.json')).write_text(json.dumps({'energyplus_version':version,'n':len(records),'weather':'Singapore IWEC, typical weather; not observed 2024','output':'Ideal-loads supply-air total cooling thermal demand','sum_runtime_seconds':sum(r['runtime_seconds'] for r in records)},indent=2))
def analyze():
    # Do not silently use a tiny pilot as final ML validation data.
    import numpy as np
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler,PolynomialFeatures
    from sklearn.linear_model import Ridge
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.dummy import DummyRegressor
    from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
    from sklearn.model_selection import GroupKFold,LeaveOneGroupOut
    file=RESULTS/'full_results.csv'
    if not file.exists():raise SystemExit('Run full 144-case grid before analyze. Pilot is EDA only.')
    rows=read_csv(file);assert len(rows)==144
    # Aspect ratio, wall/floor ratio, orientation harmonics, WWR, SHGC, shade.
    def features(r):
        angle=math.radians(float(r['orientation_deg']));L=float(r['length_m']);W=float(r['width_m'])
        return [math.log(float(r['aspect_ratio'])),2*(L+W)*3/900,math.sin(2*angle),math.cos(2*angle),float(r['wwr']),float(r['shgc']),float(r['overhang_m'])]
    X=np.array([features(r) for r in rows]);y=np.array([float(r['cooling_kwh_th_m2']) for r in rows])
    shapes=np.array([r['aspect_ratio'] for r in rows]);contexts=np.array([r['case_id'].rsplit('_',1)[0] for r in rows])
    # Square plans rotated by 90 degrees are equivalent; keep these together.
    splitcontexts=np.array([f"{r['aspect_ratio']}_{int(r['orientation_deg'])%(90 if r['aspect_ratio']=='1' else 180)}_{r['wwr']}" for r in rows])
    class StrategyMean:
        def fit(self,x,y):
            self.means={tuple(k):float(np.mean(y[np.all(x[:,5:7]==k,axis=1)])) for k in np.unique(x[:,5:7],axis=0)};return self
        def predict(self,x):return np.array([self.means[tuple(k)] for k in x[:,5:7]])
    builders={'mean':lambda:DummyRegressor(), 'strategy_mean':StrategyMean, 'ridge':lambda:make_pipeline(PolynomialFeatures(2,include_bias=False),StandardScaler(),Ridge(alpha=10)),
        'forest':lambda:RandomForestRegressor(n_estimators=200,max_depth=6,min_samples_leaf=3,random_state=2026,n_jobs=1)}
    metrics=[];predrows=[];decisions=[]
    for scheme,splitter,groups in [('within_shape_context_holdout',GroupKFold(6),splitcontexts),('leave_one_shape_out',LeaveOneGroupOut(),shapes)]:
        for name,build in builders.items():
            for fold,(train,test) in enumerate(splitter.split(X,y,groups)):
                assert not set(groups[train])&set(groups[test])
                model=build();model.fit(X[train],y[train]);p=model.predict(X[test]);lookup=dict(zip(test,p))
                metrics.append({'scheme':scheme,'model':name,'fold':fold,'test_shape':','.join(sorted(set(shapes[test]))),'n_test':len(test),
                    'mae':mean_absolute_error(y[test],p),'rmse':math.sqrt(mean_squared_error(y[test],p)),'r2':r2_score(y[test],p)})
                predrows.extend({'scheme':scheme,'model':name,'fold':fold,'case_id':rows[i]['case_id'],'observed':y[i],'predicted':lookup[i]} for i in test)
                # Comparison deliberately restricted to two single interventions.
                # Combined strategy is reported separately, not an unconstrained optimum.
                for context in sorted(set(contexts[test])):
                    candidates=[i for i in test if contexts[i]==context and rows[i]['strategy'] in ['glass','shade']]
                    assert len(candidates)==2
                    chosen=min(candidates,key=lambda i:(lookup[i],rows[i]['strategy']))
                    best=min(candidates,key=lambda i:y[i]);loss=y[chosen]-y[best]
                    decisions.append({'scheme':scheme,'model':name,'fold':fold,'context':context,'chosen':rows[chosen]['strategy'],
                        'best_thermal_only':rows[best]['strategy'],'regret_kwh_th_m2':loss,'near_tie':int(abs(y[candidates[0]]-y[candidates[1]])<.1)})
    save_csv(RESULTS/'model_metrics.csv',metrics);save_csv(RESULTS/'heldout_predictions.csv',predrows);save_csv(RESULTS/'decision_losses.csv',decisions)
    print('Saved grouped validation and thermal-only decision losses; no cost optimum claimed.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','run','analyze']);p.add_argument('--energyplus');p.add_argument('--scope',choices=['pilot','full'],default='pilot');p.add_argument('--workers',type=int,default=2);a=p.parse_args()
    if a.command=='prepare':prepare()
    elif a.command=='run':run(a.energyplus,a.scope,a.workers)
    else:analyze()
