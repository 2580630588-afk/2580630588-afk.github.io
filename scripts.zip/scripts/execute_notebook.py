from pathlib import Path
import json,sys,tempfile
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager
from jupyter_client.kernelspec import KernelSpecManager
ROOT=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='window-study-kernel-') as temp:
    folder=Path(temp)/'python3';folder.mkdir()
    (folder/'kernel.json').write_text(json.dumps({'argv':[sys.executable,'-m','ipykernel_launcher','-f','{connection_file}'],'display_name':'Python 3','language':'python'}))
    km=KernelManager(kernel_name='python3',kernel_spec_manager=KernelSpecManager(kernel_dirs=[temp]))
    nb=nbformat.read(ROOT/'analysis.ipynb',as_version=4)
    NotebookClient(nb,km=km,timeout=180,resources={'metadata':{'path':str(ROOT)}}).execute()
    nbformat.write(nb,ROOT/'analysis.ipynb')
print('Notebook executed successfully.')
