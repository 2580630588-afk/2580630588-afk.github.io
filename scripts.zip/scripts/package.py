"""Create a compact submission; exclude local environments and large run databases."""
from pathlib import Path
import os,hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
files=[]
for current,dirs,names in os.walk(ROOT,followlinks=False):
    dirs[:]=[d for d in dirs if d not in {'node_modules','.venv','__pycache__','runs','build','.ipynb_checkpoints'}]
    for name in names:
        p=Path(current)/name
        if p.suffix not in {'.pyc','.zip'} and name!='package_manifest.json':files.append(p)
manifest={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
mp=ROOT/'package_manifest.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8');files.append(mp)
out=ROOT.parent/'BPS5231_Window_Transfer_Interim.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out, 'files',len(files),'bytes',out.stat().st_size)
