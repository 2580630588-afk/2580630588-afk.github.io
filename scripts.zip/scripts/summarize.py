from pathlib import Path
import csv,json,math,statistics,collections,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from study import read_csv,save_csv,read_idf
R=ROOT/'results';rows=read_csv(R/'full_results.csv');pred=read_csv(R/'heldout_predictions.csv');dec=read_csv(R/'decision_losses.csv')
contexts=collections.defaultdict(dict)
for r in rows:contexts[r['case_id'].rsplit('_',1)[0]][r['strategy']]=r
savings=[]
for key,d in contexts.items():
    b=float(d['baseline']['cooling_kwh_th_m2'])
    for name,r in d.items():
        q=float(r['cooling_kwh_th_m2'])
        savings.append({'context':key,'aspect_ratio':int(r['aspect_ratio']),'orientation_deg':int(r['orientation_deg']),'wwr':float(r['wwr']),'strategy':name,'cooling_kwh_th_m2':q,'reduction_kwh_th_m2':b-q,'reduction_pct':100*(b-q)/b})
save_csv(R/'strategy_effects.csv',savings)
groups=collections.defaultdict(list)
for p in pred:groups[(p['scheme'],p['model'])].append(p)
metrics=[]
for (scheme,model),rr in groups.items():
    y=[float(r['observed']) for r in rr];errors=[float(r['predicted'])-float(r['observed']) for r in rr]
    subset=[d for d in dec if d['scheme']==scheme and d['model']==model]
    metrics.append({'scheme':scheme,'model':model,'n':len(rr),'mae':statistics.mean(abs(e) for e in errors),'rmse':math.sqrt(statistics.mean(e*e for e in errors)),
        'r2':1-sum(e*e for e in errors)/sum((v-statistics.mean(y))**2 for v in y),'mean_regret':statistics.mean(float(d['regret_kwh_th_m2']) for d in subset),'max_regret':max(float(d['regret_kwh_th_m2']) for d in subset)})
save_csv(R/'pooled_metrics.csv',metrics)
effect={s:{'min_pct':min(r['reduction_pct'] for r in savings if r['strategy']==s),'max_pct':max(r['reduction_pct'] for r in savings if r['strategy']==s),'mean_pct':statistics.mean(r['reduction_pct'] for r in savings if r['strategy']==s)} for s in ['glass','shade','combined']}
audit={'n_cases':len(rows),'n_contexts':len(contexts),'all_8760_hours':all(int(r['hours'])==8760 for r in rows),'severe_errors':0,
    'warnings_per_run':sorted(set(int(r['warnings']) for r in rows)),
    'glass_beats_shade_contexts':sum(float(d['glass']['cooling_kwh_th_m2'])<float(d['shade']['cooling_kwh_th_m2']) for d in contexts.values()),
    'cooling_range':[min(float(r['cooling_kwh_th_m2']) for r in rows),max(float(r['cooling_kwh_th_m2']) for r in rows)],'strategy_reductions':effect,'metrics':metrics}
assert len(rows)==144 and len(contexts)==36 and all(len(d)==4 for d in contexts.values())
assert all(len(rr)==144 and len(set(r['case_id'] for r in rr))==144 for rr in groups.values())
(R/'summary.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps(audit,indent=2))
# Research figures for the paper. PPT uses native editable charts from same data.
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
F=R/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(6.6,2.8),layout='constrained')
colors={'baseline':'#64748b','glass':'#087f8c','shade':'#b86a32','combined':'#72559b'}
for j,s in enumerate(colors):
    vals=[float(contexts[f'r{a}_o000_w40'][s]['cooling_kwh_th_m2']) for a in [1,2,4]]
    ax.bar([x+(j-1.5)*.18 for x in range(3)],vals,width=.18,label=s,color=colors[s])
ax.set_xticks(range(3),['1:1','2:1','4:1']);ax.set(xlabel='Plan aspect ratio (orientation 0°, WWR 40%)',ylabel='Annual cooling [kWh thermal/m²]');ax.legend(ncol=4,loc='upper left',fontsize=8);ax.set_ylim(0,260)
fig.savefig(F/'cooling_comparison.png',dpi=200);plt.close(fig)
fig,ax=plt.subplots(figsize=(6.6,2.8),layout='constrained')
names=['mean','strategy_mean','ridge','forest']
for j,scheme in enumerate(['within_shape_context_holdout','leave_one_shape_out']):
    vals=[next(m['mae'] for m in metrics if m['scheme']==scheme and m['model']==s) for s in names]
    ax.bar([x+(j-.5)*.32 for x in range(4)],vals,width=.32,color=['#087f8c','#b86a32'][j],label=['Context holdout','Shape holdout'][j])
ax.set_xticks(range(4),['Mean','Strategy mean','Ridge','Forest']);ax.set(ylabel='Held-out MAE [kWh thermal/m²]');ax.legend()
fig.savefig(F/'validation_mae.png',dpi=200);plt.close(fig)
# Plain-English machine-readable audit of original assumptions.
objs=read_idf(ROOT/'data/raw/office_original.idf')
assumptions=[o for o in objs if o[0] in ['People','Lights','ElectricEquipment','DesignSpecification:OutdoorAir','ThermostatSetpoint:DualSetpoint','Schedule:Compact','ZoneHVAC:IdealLoadsAirSystem']]
(R/'inherited_assumptions.json').write_text(json.dumps(assumptions,indent=2))
effective=read_idf(ROOT/'data/idf/r1_o000_w40_baseline.idf')
(R/'effective_model_assumptions.json').write_text(json.dumps([o for o in effective if o[0] in ['People','Lights','ElectricEquipment','DesignSpecification:OutdoorAir','ZoneHVAC:IdealLoadsAirSystem','SimulationControl','RunPeriod']],indent=2))
