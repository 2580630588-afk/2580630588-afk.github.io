"""Independent integrity checks for the delivered experiment and predictions."""
from pathlib import Path
import csv,json,hashlib,math,collections
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results'
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
design=read(ROOT/'data/design_matrix.csv');runs=read(R/'full_results.csv');geo=read(R/'geometry_checks.csv')
ids={r['case_id'] for r in design};assert len(ids)==144
assert ids=={r['case_id'] for r in runs}=={r['case_id'] for r in geo}
for row in geo:
    assert abs(float(row['floor_area_m2'])-900)<1e-5
    intended=float(next(r['wwr'] for r in design if r['case_id']==row['case_id']))
    assert abs(float(row['verified_wwr'])-intended)<1e-7
weather=(ROOT/'data/raw/singapore_iwec.epw').read_bytes()
for row in runs:
    assert int(row['hours'])==8760 and float(row['cooling_kwh_th_m2'])>0
    assert math.isclose(float(row['cooling_kwh_th_m2'])*900,float(row['cooling_kwh_th']),rel_tol=1e-12)
    expected=hashlib.sha256((ROOT/'data/idf'/(row['case_id']+'.idf')).read_bytes()+weather).hexdigest()
    assert expected==row['input_hash'],'Stale simulation output'
for name,h in json.loads((R/'input_hashes.json').read_text()).items():assert hashlib.sha256((ROOT/'data/raw'/name).read_bytes()).hexdigest()==h
pred=read(R/'heldout_predictions.csv');groups=collections.defaultdict(list)
for row in pred:groups[(row['scheme'],row['model'])].append(row)
assert len(groups)==8
for key,rr in groups.items():assert len(rr)==144 and {r['case_id'] for r in rr}==ids
if (R/'run_logs').exists():
    logs=list((R/'run_logs').glob('*.err'));assert len(logs)==144
    for path in logs:
        t=path.read_text(errors='replace');assert 'Completed Successfully' in t and '** Severe **' not in t
report={'cases':144,'source_hashes_verified':True,'geometry_verified':True,'simulation_hashes_current':True,'each_model_each_case_predicted_once_per_scheme':True,'annual_hours_per_case':8760,'thermal_units_not_electricity':True}
(R/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
