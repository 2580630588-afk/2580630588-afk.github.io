import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {Presentation,PresentationFile} from '@oai/artifact-tool';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const tmp=process.env.BUILD_DIR||path.join(root,'build');await fs.mkdir(tmp,{recursive:true});
const S=JSON.parse(await fs.readFile(path.join(root,'results/summary.json'),'utf8'));
const refs=JSON.parse(await fs.readFile(path.join(root,'references.json'),'utf8'));
const csv=async(file)=>{const lines=(await fs.readFile(path.join(root,file),'utf8')).replace(/^\uFEFF/,'').trim().split(/\r?\n/).map(x=>x.split(','));return lines.slice(1).map(r=>Object.fromEntries(lines[0].map((k,i)=>[k,r[i]])));};
const rows=await csv('results/full_results.csv'),folds=await csv('results/model_metrics.csv');
const G='within_shape_context_holdout',H='leave_one_shape_out';
const val=(scheme,model,key='mae')=>S.metrics.find(x=>x.scheme===scheme&&x.model===model)[key];
const allrefs=refs.map(r=>`[${r.id}] ${r.citation}\n${r.url}`).join('\n\n');
const p=Presentation.create({slideSize:{width:1280,height:720}});
const N='#173247',T='#087F8C',O='#B86A32',GRAY='#607080',BG='#FFFFFF';
function text(s,t,x,y,w,h,size=28,color=N,bold=false){const sh=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});sh.text=t;sh.text.style={typeface:'Arial',fontSize:size,color,bold,autoFit:'none'};return sh;}
function slide(title,note,foot=''){const s=p.slides.add();s.background.fill=BG;text(s,title,60,40,1160,77,43,N,true);if(foot)text(s,foot,60,643,1115,60,18,GRAY);text(s,String(p.slides.items.length),1190,664,40,27,18,GRAY);s.speakerNotes.textFrame.setText(note+'\n\n'+allrefs);return s;}
function table(s,values,{y=170,h=330,widths=null,size=25}={}){const t=s.tables.add({rows:values.length,columns:values[0].length,left:60,top:y,width:1160,height:h,values,columnWidths:widths??Array(values[0].length).fill(1160/values[0].length)});for(let r=0;r<values.length;r++)for(let c=0;c<values[0].length;c++){const z=t.getCell(r,c);z.fill=r===0?N:r%2===0?'#F0F5F6':BG;z.text.style={typeface:'Arial',fontSize:size,color:r===0?BG:N,bold:r===0};}return t;}
function bar(s,categories,series,{y=172,h=415,ylab='Cooling [kWh thermal/m²/year]',max=undefined}={}){return s.charts.add('bar',{position:{left:65,top:y,width:1135,height:h},categories,series:series.map(q=>({...q,values:q.values.map(v=>+Number(v).toFixed(5))})),barOptions:{direction:'column',grouping:'clustered',gapWidth:60},hasLegend:series.length>1,legend:{position:'bottom',textStyle:{typeface:'Arial',fontSize:20,fill:N}},xAxis:{textStyle:{typeface:'Arial',fontSize:23,fill:N}},yAxis:{title:{text:ylab,textStyle:{typeface:'Arial',fontSize:20,fill:N}},min:0,max,numberFormatCode:'0.0',textStyle:{typeface:'Arial',fontSize:19,fill:GRAY},majorGridlines:{fill:'#E3EAED',width:.5}},chartFill:BG,chartLine:{fill:'none',width:0}});}
let s=slide('Window strategies across office plan shapes','中文题目：新加坡办公建筑外窗太阳得热控制策略的跨形态适用性。研究为期中个人工作，使用开放原型进行受控模拟。不是2024年BCA实测研究，也没有预测真实空调电耗。','BPS5231 · AI for Sustainable Building Design · Interim study · 3 October 2026');
text(s,'Cooling-demand prediction\non a withheld plan shape',60,191,1160,165,58,N,true);
text(s,'Open office prototype · 144 annual simulations\nGrouped regression validation',60,429,1160,115,31,T);

s=slide('Research questions','第一问是物理模拟中的措施效果是否随形态变化，第二问是模型跨形态预测误差，第三问是错误推荐损失。第三问当前结果退化，需要明确说明，不能包装成100%正确。','Scope: rectangular intermediate floors; cooling thermal demand only.');
text(s,'1   How do strategy effects change across plan shapes?',60,182,1150,90,32,N,true);
text(s,'2   Can a model predict a shape excluded from training?',60,324,1150,90,32,N,true);
text(s,'3   Does prediction error change the chosen intervention?',60,466,1150,100,32,T,true);

s=slide('Prior work and the bounded contribution','文献[3]已有建筑代理模型加改造优化，[4]已有近似改造决策。不能把EnergyPlus与机器学习组合本身称为创新。本作业贡献是透明的小范围跨形态验证、简单基线和决策指标失效报告。','Related work [3,4]; model source [1]. Full citations in notes and paper.');
table(s,[['Prior work','Relevance'],['Markarian et al. (2024)','Surrogate-based retrofit optimisation'],['Thrampoulidis et al. (2021)','Approximation of retrofit solutions'],['Buildings.sg','Open office model for reproducible experiments']],{y:163,h:295,widths:[475,685]});
text(s,'Contribution: a controlled transfer test with simple baselines\nand explicit checks of what the results cannot establish.',60,513,1150,106,30,T,true);

s=slide('Adapted intermediate-floor model','源文件10×10m，含五个热区。修改为900m²，外围热区保持3m进深，不做简单整体拉伸，防止外围深度随长宽比变化。顶板与楼板绝热。原区间固定混合流量去掉，不增加区间整体空气流动。修改记录在指南。','Adapted from [1]; changes are study assumptions, not empirical calibration.');
table(s,[['Item','Study model'],['Floor area / height','900 m² / 3 m'],['Thermal zones','Five; perimeter depth = 3 m'],['Floor and ceiling','Adiabatic intermediate-floor boundaries'],['Cooling system','Ideal loads; thermal demand, not electricity']],{y:161,h:370,widths:[420,740]});
text(s,'Controlled weather, schedules and internal gains across all cases',60,566,1150,47,27,T);

s=slide('Experimental design','三种形态、四个旋转角、三个窗墙比、四种措施，共144次模拟。每个形态48次。36个情景中各自包含4个配对方案。模拟行不是实测独立样本。角度使用IDF建筑北向角，反向立面相同。','144 simulations = 36 contexts × 4 paired strategies.');
table(s,[['Factor','Levels','Count'],['Plan aspect ratio','1:1 / 2:1 / 4:1','3'],['Building rotation','0° / 45° / 90° / 135°','4'],['Window-to-wall ratio','20% / 40% / 60%','3'],['Window strategy','Baseline / glass / shade / combined','4']],{y:166,h:360,widths:[360,650,150]});
text(s,'Same context = same shape, rotation and WWR',60,565,1150,49,29,T);

s=slide('Geometry audit and input variation','这是模型输入EDA，不是实测建筑几何统计。固定900m²面积，改变长宽比后周长及墙面面积会变化；这些是形态变化的组成部分。三种长宽比并不等同于覆盖所有建筑形态。所有144个模型面积、窗墙比、内表面邻接通过代码检查。','Input audit: constant floor area and height; changing exposed wall area.');
table(s,[['Aspect ratio','Length × width','External wall / floor'],['1:1','30.00 × 30.00 m','0.400'],['2:1','42.43 × 21.21 m','0.424'],['4:1','60.00 × 15.00 m','0.500']],{y:180,h:282,widths:[320,475,365]});
text(s,'Each generated model passes area, WWR and shared-face checks.\nThree equal-area rectangles define a limited test domain.',60,518,1145,97,29,T);

s=slide('Four controlled window options','SHGC和挑檐深度是研究设定。基线0.60与源模型0.12不同，已明确记录。U和VT保持不变，属于理想化控制比较，不是实际产品报价。组合很可能在冷却需求上占优，因此不将无约束选组合当研究发现。','Fixed glazing U = 1.6 W/(m² K), VT = 0.60. No cost or daylight optimisation.');
table(s,[['Option','SHGC','Overhang depth'],['Baseline','0.60','0.00 m'],['Glass only','0.30','0.00 m'],['Shade only','0.60','0.60 m'],['Combined','0.30','0.60 m']],{y:163,h:363,widths:[570,270,320]});
text(s,'Paired effects are measured against the same-context baseline.',60,564,1140,50,28,T);

s=slide('Operating assumptions and output boundary','室外空气由源模型6ACH改0.6ACH，并关闭热回收，避免不加审查继承设置。采用26摄氏度和源时刻表。0.6ACH是研究假设，后期敏感性验证，并非规范结论。输出供风总冷却热量包含所设通风及湿度控制。全年8760小时，五热区求和除900。','Singapore IWEC typical weather [5]; no claim about observed 2024 conditions.');
table(s,[['Control','Setting'],['Cooling / outdoor air','26°C / 0.6 ACH, occupancy schedule'],['Heat recovery','Disabled'],['Lighting / equipment','9 / 22 W per m²; no daylight dimming'],['Weather / calendar','Singapore IWEC / non-leap 2006 calendar']],{y:152,h:355,widths:[415,745],size:24});
text(s,'q = sum of hourly zone cooling energy / floor area\nUnits: kWh thermal per m² per year',60,549,1140,81,28,T,true);

s=slide('EDA: paired cooling demand','图中只比较旋转0度、窗墙比40%的三种形态，避免混合所有条件后把变化都归因于形态。柱图取真实年度模拟结果。需求变化不等于实测电量节约。','Annual simulations; rotation = 0°, WWR = 40%. Source: full_results.csv.');
bar(s,['1:1','2:1','4:1'],[['baseline','#687B8C'],['glass',T],['shade',O],['combined','#73569A']].map(([name,fill])=>({name,fill,values:[1,2,4].map(a=>+rows.find(r=>r.case_id===`r${a}_o000_w40_${name}`).cooling_kwh_th_m2)})),{max:180});

s=slide('EDA: reductions across all 36 contexts','范围是所有长宽比、朝向及窗墙比共同变化结果，不是形态独立效应。每条百分比都使用自己情景的基线。当前玻璃单项在全部情景中优于所设遮阳，所以无排名交叉，不能制造交叉结果。','Ranges combine shape, orientation and WWR variation; not shape-only effects.');
table(s,[['Option','Minimum reduction','Maximum reduction'],...['glass','shade','combined'].map(k=>[k,`${S.strategy_reductions[k].min_pct.toFixed(2)}%`,`${S.strategy_reductions[k].max_pct.toFixed(2)}%`])],{y:178,h:291,widths:[420,370,370],size:27});
text(s,'Glass has lower cooling demand than this overhang\nin all 36 contexts; this does not compare cost effectiveness.',60,528,1140,91,30,T,true);

s=slide('Validation by context and by shape','情景分组保证同样形态朝向窗墙比的四个方案不被拆分，正方形0与90、45与135旋转合并为同组。形态留一每次96训练48测试，2:1中间形态与两个端点外推应分开看。未用测试数据调参。','Preprocessing is fitted on training folds only. Grouping follows [6].');
table(s,[['Evaluation','Held out together','Purpose'],['Grouped 6-fold','Complete contexts; square symmetry grouped','Familiar-shape prediction'],['Leave one shape out','All 48 runs of one aspect ratio','Prediction on an unseen shape']],{y:193,h:270,widths:[330,490,340],size:24});
text(s,'Train on 1:1 + 4:1 → test 2:1: interpolation\nTrain on 1:1 + 2:1 → test 4:1: endpoint extrapolation',60,517,1140,99,29,T);

s=slide('Fixed models and baseline checks','对应L2和L3回归、标准化及模型评价，L5随机森林和EDA。Ridge二阶多项式加正则化，非纯线性主效应。全部模型相同训练测试划分。比较简单均值及按措施均值，防止AI有用只是利用措施平均差别。','Exploratory fixed settings; no test-driven tuning or deep learning.');
table(s,[['Model','Specification'],['Mean','Training-fold mean cooling demand'],['Strategy mean','Training-fold mean for each option'],['Polynomial Ridge','Degree 2; training-fold scaling; alpha = 10'],['Random forest','200 trees; depth ≤6; leaf ≥3; seed 2026']],{y:166,h:365,widths:[370,790],size:25});
text(s,'Report MAE, RMSE and R² from held-out predictions.',60,573,1140,43,29,T);

s=slide('Prediction error under both validation schemes','所有数字来自最终0.6ACH无热回收情景。评价汇总来自每个案例一次的折外预测。不要用相差很小的MAE自动宣称某个模型更优，也不要把三个形态折当置信区间。','MAE: kWh thermal/(m² year). Each model has 144 held-out predictions per scheme.');
bar(s,['Mean','Strategy mean','Ridge','Forest'],[{name:'Context holdout',fill:T,values:['mean','strategy_mean','ridge','forest'].map(m=>val(G,m))},{name:'Shape holdout',fill:O,values:['mean','strategy_mean','ridge','forest'].map(m=>val(H,m))}],{ylab:'Held-out MAE [kWh thermal/m²/year]',max:18});

s=slide('Error depends on the withheld shape','按留出形态分析更有意义。森林可能擅长中间形态但边界外推较弱。当前测试只有三种矩形，不表明对其他面积、L形平面或真实建筑也适用。','Leave-one-shape-out MAE; two shapes for training, one for testing.');
bar(s,['1:1 withheld','2:1 withheld','4:1 withheld'],[{name:'Ridge',fill:T,values:['1','2','4'].map(a=>+folds.find(r=>r.scheme===H&&r.model==='ridge'&&r.test_shape===a).mae)},{name:'Forest',fill:O,values:['1','2','4'].map(a=>+folds.find(r=>r.scheme===H&&r.model==='forest'&&r.test_shape===a).mae)}],{ylab:'Held-out MAE [kWh thermal/m²/year]'});

s=slide('Zero selection loss does not prove useful AI','这是本研究最重要的逻辑检查。玻璃在所有36情景中都优于给定挑檐，因此任何固定选择玻璃的方法损失也为0。均值模型预测打平后默认玻璃，恰好也得到0。不能写AI100%推荐正确。将连续需求和效果幅度预测作为主结果。','Thermal selection only; no equal-cost assumption and no universal ranking claim.');
text(s,'Loss = simulated demand of the chosen single option\n          − lowest simulated demand of the two single options',60,165,1140,115,31,N);
text(s,'All models have zero loss — including the constant predictor.',60,343,1140,85,32,T,true);
text(s,'Reason: glass beats the specified shade in every context.\nThe current two-option decision test is not discriminating.',60,480,1140,108,30,N);

s=slide('Limitations and the next experiment','已完成期中数据、EDA、回归验证及论文。后续先声明未见过长宽比和另一个面积，再做外部模拟测试；当前代码900写死，增加面积须同时改模型和归一化。通风和运行敏感性为下一步，不把已有快照与新结果混用。研究没有建筑实测验证，没有日光、成本及真实HVAC耗电。','Next stage: predefine new tests before generating more outcomes.');
table(s,[['Current boundary','Next test'],['Three equal-area rectangles','Untouched aspect ratios and a second area'],['One ventilation and schedule setting','Ventilation and operation sensitivities'],['Ideal-loads thermal outcome','Retain this boundary or explicitly model HVAC'],['Degenerate binary selection','Prioritise demand-reduction prediction error']],{y:166,h:350,widths:[540,620],size:24});
text(s,'Do not search parameter values merely to manufacture a ranking reversal.',60,559,1140,66,27,T,true);

s=slide('References and reproducible submission','正式完整参考文献见论文末页、references.json及本页备注。提交PPT、三页论文、脚本和数据。无需为课程作业训练深度学习。中文指南列出所有命令，打包文件不含EnergyPlus二进制或大量SQL。','Paper, code, original inputs, 144-case results and Chinese execution guide are included.');
table(s,[['Reference','Use'],['[1] City Syntax Lab — Buildings.sg','Open office prototype'],['[2,5] EnergyPlus / Singapore IWEC','Output definition and weather'],['[3] Markarian et al., 2024','Surrogates for retrofit optimisation'],['[4] Thrampoulidis et al., 2021','Surrogates for retrofit solutions'],['[6] Scikit-learn documentation','Grouped model evaluation']],{y:157,h:405,widths:[710,450],size:24});
const candidate=path.join(tmp,'candidate.pptx');await(await PresentationFile.exportPptx(p)).save(candidate);
await fs.mkdir(path.join(tmp,'previews'),{recursive:true});
for(let i=0;i<p.slides.items.length;i++){const blob=await p.export({slide:p.slides.items[i],format:'png',scale:1});await fs.writeFile(path.join(tmp,'previews',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await blob.arrayBuffer()));}
console.log(JSON.stringify({candidate,slides:p.slides.items.length}));
if(process.env.PRESENTATION_SKILL_DIR){
 const skill=process.env.PRESENTATION_SKILL_DIR;const {finalizePresentation}=await import(pathToFileURL(path.join(skill,'container_tools/artifact_tool_utils.mjs')).href);
 const result=await finalizePresentation({workspaceDir:process.env.WORKSPACE_DIR||root,candidatePath:candidate,finalPath:path.join(root,'deliverables/interim_slides.pptx'),pythonExecutable:process.env.RUNTIME_PYTHON,
 integrityValidatorPath:path.join(skill,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(skill,'container_tools/inspect_presentation_layout_geometry.py'),
 layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit',...[3,4,5,6,7,8,10,11,12,16,17].flatMap(n=>['--require-native-table-slide',String(n)])],requiredNativeTableOwnerSlides:[3,4,5,6,7,8,10,11,12,16,17],requiredNativeChartOwnerSlides:[9,13,14],
 fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,materializeLiteralChartWorkbooks:true,receiptPath:path.join(tmp,'validation.json')});console.log(JSON.stringify(result));
}else{await fs.copyFile(candidate,path.join(root,'deliverables/interim_slides.pptx'));console.log('PPTX exported; inspect rendering before submission.');}
