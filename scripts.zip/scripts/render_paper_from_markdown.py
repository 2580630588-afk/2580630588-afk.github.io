"""Render the current editable Markdown without overwriting it or regenerating prose."""
from pathlib import Path
import re,hashlib,json,shutil
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph,Table,TableStyle,Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import reportlab
from matplotlib.mathtext import math_to_image
from matplotlib.font_manager import FontProperties
from PIL import Image as PILImage
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'deliverables/interim_paper_editable.md'
OUT=ROOT/'deliverables/interim_paper.pdf'
raw=SOURCE.read_bytes();text=raw.decode('utf-8-sig');lines=text.splitlines()
title=lines[0].removeprefix('# ').strip()
i=next(n for n,line in enumerate(lines) if line.startswith('## '))
subtitle=' | '.join(line.strip().strip('*').strip() for line in lines[1:i] if line.strip())
def inline(value):
    value=value.replace(r'$\sin(2\theta)$','sin(2 theta)').replace(r'$\cos(2\theta)$','cos(2 theta)')
    value=value.replace(r'$A = 900\,\mathrm{m}^{2}$','<i>A</i> = 900 m²').replace('$Q$','<i>Q</i>')
    value=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<link href="\2" color="#15546a">\1</link>',value)
    value=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',value)
    value=re.sub(r'\*\s*(.+?)\*',r'<i>\1</i>',value)
    return re.sub(r'`([^`]+)`',r'\1',value)
blocks=[]
while i<len(lines):
    line=lines[i].strip()
    if not line:i+=1;continue
    if line.startswith(('## ','### ')):blocks.append(('h',line.lstrip('#').strip()));i+=1;continue
    if line=='$$':
        eq=[];i+=1
        while i<len(lines) and lines[i].strip()!='$$':eq.append(lines[i].strip());i+=1
        assert i<len(lines),'Unclosed math block'
        blocks.append(('math',' '.join(eq)));i+=1;continue
    match=re.fullmatch(r'!\[.*?\]\((.*?)\)',line)
    if match:
        blocks.append(('img',match.group(1)));i+=1;continue
    if ' | ' in line and not line.startswith('['):
        rows=[]
        while i<len(lines) and ' | ' in lines[i]:
            r=[v.strip() for v in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[:\- ]+',v) for v in r):rows.append(r)
            i+=1
        blocks.append(('table',rows));continue
    paragraph=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('## ','### ','![','$$')):
        paragraph.append(lines[i].strip());i+=1
    content=' '.join(paragraph)
    small=content.startswith(('[','Table ','Figure ','<b>Keywords','**[' ,'**Table','**Figure','**Keywords'))
    blocks.append(('small' if small else 'p',inline(content)))
fontdir=Path(reportlab.__file__).parent/'fonts'
for name,file in [('Vera','Vera.ttf'),('VeraBold','VeraBd.ttf'),('VeraItalic','VeraIt.ttf')]:pdfmetrics.registerFont(TTFont(name,str(fontdir/file)))
pdfmetrics.registerFontFamily('Vera',normal='Vera',bold='VeraBold',italic='VeraItalic',boldItalic='VeraBold')
styles={'p':ParagraphStyle('p',fontName='Vera',fontSize=8.7,leading=11.4,spaceAfter=7),
        'h':ParagraphStyle('h',fontName='VeraBold',fontSize=10.7,leading=13.5,spaceBefore=5,spaceAfter=7),
        'small':ParagraphStyle('small',fontName='Vera',fontSize=7.2,leading=9.5,spaceAfter=6)}
build=ROOT.parents[1]/'work/paper_markdown_update';build.mkdir(parents=True,exist_ok=True)
draft=build/'updated.pdf'
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame, KeepTogether, FrameBreak
from pypdf import PdfReader
width=254
titleflow=Paragraph(title,ParagraphStyle('title',fontName='VeraBold',fontSize=16,leading=20))
_,titleheight=titleflow.wrap(525,100)
def decorate(c,doc):
    c.setTitle(title)
    c.setFont('Vera',8)
    c.drawString(35,814,subtitle)
    c.drawRightString(560,24,str(doc.page))
    if doc.page==1:titleflow.drawOn(c,35,788-titleheight)
def frames(top):
    return [Frame(35+col*271,40,width,top-40,id=str(col),leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0) for col in range(2)]
doc=BaseDocTemplate(str(draft),pagesize=(595.276,841.89))
doc.addPageTemplates([PageTemplate(id='first',frames=frames(788-titleheight-17),onPage=decorate,autoNextPageTemplate='body'),PageTemplate(id='body',frames=frames(788),onPage=decorate)])
story=[]
for index,(kind,value) in enumerate(blocks):
    if kind=='h' and value=='References':story.append(FrameBreak)
    if kind in styles:
        flow=Paragraph(value,styles[kind])
        if kind=='h':flow.keepWithNext=True
    elif kind=='img':
        flow=Image(str((SOURCE.parent/value).resolve()),width=width,height=108)
        flow.spaceAfter=6
        flow.keepWithNext=True
    elif kind=='math':
        file=build/('equation-'+hashlib.sha256(value.encode()).hexdigest()[:12]+'.png')
        math_to_image('$'+value+'$',str(file),prop=FontProperties(size=11),dpi=300,format='png')
        with PILImage.open(file) as im:iw,ih=im.size
        factor=min(72/300,width/iw)
        flow=Image(str(file),width=iw*factor,height=ih*factor)
        flow.hAlign='CENTER';flow.spaceBefore=5;flow.spaceAfter=9
    else:
        cells=[[Paragraph(inline(v),styles['small']) for v in row] for row in value]
        flow=Table(cells,colWidths=[width/len(cells[0])]*len(cells[0]))
        flow.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),HexColor('#e7eef0')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
        flow.spaceAfter=9;flow.keepWithNext=True
    story.append(flow)
doc.build(story)
page_count=len(PdfReader(draft).pages)
assert SOURCE.read_bytes()==raw,'Source must remain unchanged'
if OUT.exists() and not (build/'previous.pdf').exists():shutil.copy2(OUT,build/'previous.pdf')
shutil.copy2(draft,OUT)
(build/'source_audit.json').write_text(json.dumps({'source_sha256':hashlib.sha256(raw).hexdigest(),'source_unchanged':True,'pages':page_count,'blocks':len(blocks)},indent=2))
print(f'Updated PDF with continuous column flow; source unchanged; {page_count} pages.')
