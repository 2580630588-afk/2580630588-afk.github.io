from pathlib import Path
import json,csv,shutil,zipfile,hashlib
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results';D=ROOT/'deliverables';D.mkdir(exist_ok=True)
S=json.loads((R/'summary.json').read_text());metrics={(r['scheme'],r['model']):r for r in S['metrics']};H='leave_one_shape_out'
guide=fr'''# 外窗策略跨形态适用性研究 操作与答辩指南

中文题目：新加坡办公建筑外窗太阳得热控制策略的跨形态适用性——基于开放原型与机器学习代理模型的冷却需求分析。

这是个人期中研究，正式材料为英文幻灯片及英文三页会议论文；本指南用于理解、复现和答辩。研究日期为2026年10月3日。模型采用典型气象年，不再延续“2024年BCA实测数据”题目。不要将旧题目、旧EUI结果混入本次提交。

## 一 期中要求与交付内容

| 老师要求 | 对应交付 |
|---|---|
| Slides：问题、数据、EDA图及解释、潜在方法 | interim_slides.pptx，可编辑图表、中文讲稿备注 |
| Conference paper style，1—3页，至少Abstract、Introduction、Related Works、Methods | interim_paper.pdf，3页；含初步模拟结果与局限；可编辑文本在interim_paper_editable.md |
| Code，GitHub或Colab等形式均可 | scripts、requirements.txt、data、results、analysis.ipynb |

本地代码已经满足“提交代码”的内容准备；尚未替你创建或发布GitHub仓库。上传课程平台前，加入你的姓名、学号，确认教师是否另外提供格式模板。本稿采用通用双栏会议论文版式，不冒称官方IBPSA模板。

## 二 研究究竟回答什么

问题1：在控制面积、运行与系统条件后，玻璃和遮阳的冷却需求降低幅度，是否随办公平面形态变化？

问题2：在两种形态上训练的回归模型，对第三种未见过的形态能预测到什么程度？

问题3：预测误差是否会导致两种单项措施选择错误？当前第三个问题已发现辨别力不足，不能作为主要贡献。

AI承担的是对模拟结果进行监督学习回归及跨形态验证。EnergyPlus生成物理模拟样本。两者并不证明真实建筑因果节能量，也不自动意味着使用AI比直接模拟更省时间。此网格很小，模拟本身已很快，不能夸大加速价值。

## 三 实验范围和变量

| 因素 | 水平或固定值 |
|---|---|
| 中间层面积与层高 | 900 m²、3 m；楼板及顶板绝热 |
| 长宽比 | 1、2、4；尺寸30×30、42.43×21.21、60×15 m |
| 热区 | 五区，外围热区进深固定3 m |
| 建筑旋转角 | 0、45、90、135度；以IDF坐标及建筑北向角为准 |
| 各外墙窗墙比 | 20%、40%、60%；窗居中，宽高按平方根同比缩放 |
| 基线 | SHGC 0.60，无外遮阳 |
| 玻璃单项 | SHGC 0.30，无外遮阳 |
| 遮阳单项 | SHGC 0.60，窗头水平挑檐深0.60 m |
| 组合方案 | SHGC 0.30，挑檐深0.60 m |
| 玻璃其他属性 | U=1.6 W/(m² K)，可见光透射比0.60固定 |
| 冷却设定 | 26°C，理想负荷无限容量；湿度控制继承源模型 |
| 运行 | 工作日09—18点按原型分时人数比例，周末关闭；不是实测使用率 |
| 内部负荷 | 照明9 W/m²，设备22 W/m²，人员密度0.047501人/m² |
| 室外空气 | 0.6 ACH，随使用时刻表；无热回收；不是法规结论 |
| 气象 | 新加坡IWEC，WMO486980；不是2024实际天气 |

3种形态×4种朝向×3种窗墙比×4个方案=144次模拟，对应36个建筑情景。每个情景四个方案配对比较。它们不是144栋实测建筑，也不是144个独立随机样本。

同一面积下长宽比变化会同时改变外墙面积和外围区比例；这是平面形态变化的一部分。本研究没有分离每条物理路径的因果贡献。朝向与窗墙比固定时才能讨论形态间差异，不能把跨所有工况的结果范围都归因于形态。

## 四 原模型修改记录

原始文件完整保留在data/raw/office_original.idf。源文件是10×10 m五区模型，原SHGC为0.12、室外空气6 ACH且带热回收。它不能不经检查就被称为本研究基线。

study.py逐项实施：扩大并重构几何；固定3 m外围进深；重算体积与面积；屋顶、楼板改绝热；去掉原固定流量的区间混合；按窗墙比重建四面窗；统一U值与可见光透射比；设定SHGC和挑檐；取消理想系统容量限制；将室外空气改为0.6 ACH且关闭热回收；删除无关的生命周期价格条目和未运行的设计日；用EPW地点校正Site:Location。

所有修改都是研究控制条件，未宣称对实际办公建筑完成校准。初次运行中发现SQL的WarmupFlag为空；提取代码使用COALESCE并限制天气运行环境，随后验证8760小时及每小时5个热区。最终结果均使用统一后的模型，未混入早期运行值。

## 五 计算方法

全年冷却需求强度 q = 五个热区逐时供风总冷却能量之和 ÷ 3,600,000 ÷ 900，单位kWh热量/(m²·年)。它包括所设通风和湿度控制下的供风处理需求，不能直接写成冷机用电。

降低率 = (同情景基线q − 方案q) / 同情景基线q ×100%。不跨形态错配基线。

模型输入：ln(长宽比)、外墙面积/楼面面积、sin(2θ)、cos(2θ)、窗墙比、SHGC、挑檐深度。反向相同立面使180度周期编码合理；如果后续各朝向开窗或遮阳不同，必须重新检查编码。

模型：训练均值、按方案分组的训练均值、二阶多项式Ridge（alpha=10，折内标准化）、随机森林（200树、最大深度6、叶最少3，seed=2026）。当前为固定探索性设置，没有使用测试集调参。若之后调参，应在每个外层训练集中进行内层分组验证。

验证A：6折按完整情景分组，四个方案不能拆开；正方形相差90度的对称旋转归入同组。

验证B：留一形态，训练96个工况、测试48个工况，轮换三次。留出2:1是该形态族中间范围的插值；留出1:1或4:1涉及边界外推。所有模型使用相同切分。

报告MAE、RMSE、R²；总指标来自每个工况恰好一次的折外预测。另报告每个留出形态指标，防止平均值掩盖边界误差。不把三个折的差异称为置信区间。

方案选择损失 = 实际模拟的被选方案q − 两个单项方案中最低q。仅比较玻璃与遮阳，组合单列；无成本数据，不能称经济最优。同预测值按固定顺序选玻璃，这条规则必须披露。

## 六 已经完成的期中结果

已完成144次年度模拟、每次8760小时，0个严重错误。每次保留6条警告：5条继承的时刻表类型限制缺失，1条未使用构造；详细日志在results/run_logs中。这些检查不是实测验证。

在全部36个情景中，玻璃单项都优于本研究设定的0.6 m挑檐。玻璃降低率为{S['strategy_reductions']['glass']['min_pct']:.2f}%—{S['strategy_reductions']['glass']['max_pct']:.2f}%，遮阳为{S['strategy_reductions']['shade']['min_pct']:.2f}%—{S['strategy_reductions']['shade']['max_pct']:.2f}%，组合为{S['strategy_reductions']['combined']['min_pct']:.2f}%—{S['strategy_reductions']['combined']['max_pct']:.2f}%。这是全部因素共同变化下的范围，不是形态单因素效应。

整种形态留出MAE：策略均值{metrics[(H,'strategy_mean')]['mae']:.2f}，Ridge {metrics[(H,'ridge')]['mae']:.2f}，随机森林{metrics[(H,'forest')]['mae']:.2f} kWh热量/(m²·年)。在这个受控形态族内，学习模型比简单均值基线更准确；还不能证明跨真实项目有效。

最重要的反例：所有模型选择损失为0，连固定均值模型也为0，因为两种措施在所有测试情景中顺序一致，平局规则刚好选玻璃。因此不能写“AI能100%正确推荐方案”。当前更有意义的是连续冷却需求及降低幅度预测，以及不同留出形态的误差。

## 七 操作步骤

### 第1步 阅读与确认提交文件
先看本指南，再看deliverables/interim_slides.pptx，最后读三页论文。论文和幻灯片应统一使用“冷却需求”，不能把单位换成电耗。备注中已有中文讲解。加入姓名、学号；若老师要求另一会议模板，仅改变排版。

### 第2步 准备本地工具
建议Windows上使用Python 3.12和EnergyPlus 24.2便携版；版本须与IDF一致。EnergyPlus官方下载：https://github.com/NatLabRockies/EnergyPlus/releases/tag/v24.2.0 。解压即可使用energyplus.exe，不需要DesignBuilder付费许可证，也不需要先使用Rhino。

进入解压后的项目根目录，在PowerShell运行：
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```
requirements.txt记录本次运行版本。如果你的包源暂不提供对应版本，先解决版本差异并记录新环境，不要把不同环境结果称为逐字节一致。

### 第3步 先复现已有结果分析
不安装EnergyPlus也可读CSV并重新做验证：
```powershell
.\.venv\Scripts\python.exe scripts/study.py analyze
.\.venv\Scripts\python.exe scripts/summarize.py
```
应输出pooled_metrics.csv、heldout_predictions.csv及图表，并与本指南的两位小数结果一致。可用analysis.ipynb逐格查看。运行前后的输出有差异，先核对版本和源文件hash。

### 第4步 生成并检查模型
```powershell
.\.venv\Scripts\python.exe scripts/study.py prepare
```
生成144个IDF与design_matrix.csv。检查geometry_checks.csv：每条面积900，窗墙比与设计值一致，5个热区；无遮阳方案0个挑檐，有遮阳方案4个挑檐。代码同时检查相邻内表面顶点一致。

### 第5步 先跑12个试验工况
把下面路径替换为你实际的EnergyPlus位置：
```powershell
$ep = 'C:\EnergyPlusV24-2-0\energyplus.exe'
.\.venv\Scripts\python.exe scripts/study.py run --energyplus $ep --scope pilot --workers 2
```
试验集为3种形态×4个方案，固定旋转0度、窗墙比40%。查看eplusout.err，确认无严重错误、每次8760小时；不是只有程序退出就算通过。

### 第6步 重跑全部工况
```powershell
.\.venv\Scripts\python.exe scripts/study.py run --energyplus $ep --scope full --workers 2
.\.venv\Scripts\python.exe scripts/study.py analyze
.\.venv\Scripts\python.exe scripts/summarize.py
```
已完成且输入hash未变的运行会复用缓存。若你需要强制重新运行，把results/runs改名作为备份后重跑。模拟会生成较大的SQL文件，课程提交可用紧凑结果表和错误日志；完整重算仍能生成SQL。

### 第7步 按问题读图
先看同一朝向和窗墙比下不同形态的四方案冷却需求柱图，再看所有情景的降低率。比较同类情景留出与形态留出误差，并打开model_metrics.csv查看每个形态。不要只挑表现最好的一折。检查玻璃、遮阳排序是否变化；当前没有变化也必须如实呈现。

### 第8步 更新论文与幻灯片
论文生成：`python scripts/build_documents.py`。论文文本段落就在该脚本，数值来自summary.json；可编辑稿也在deliverables。幻灯片源为build_slides.mjs，使用@oai/artifact-tool 2.8.84；普通使用者可直接在PPT中编辑。重新导出后要检查图表单位及每页排版。PDF是通用双栏会议风格，不是指定会议的官方模板。

### 第9步 整理代码提交
提交scripts、requirements.txt、README.md、analysis.ipynb、data/raw、design_matrix.csv及紧凑results；可提交全部生成IDF便于老师抽查。不要把EnergyPlus程序、node_modules、虚拟环境、大量SQL和个人临时文件上传。GitHub建仓及上传属于你自行决定的发布动作，本次未自动发布。

### 第10步 期中之后再扩展
先固定新验证计划，再增加1.5:1、3:1等新形态和另一个面积水平，完全留作外部模拟测试。增加新面积时不能只改表格：当前代码固定900 m²的几何与归一化也须同步参数化并检查。其次做通风和时刻表敏感性；使用独立输出目录保存各情景。不为了制造排序交叉而事后反复挑选SHGC或遮阳深度。

## 八 逻辑漏洞检查与答辩

| 容易被问的问题 | 本研究处理 |
|---|---|
| 是否又是固定小空间研究 | 当前有3个等面积矩形形态且整类留出；仍只是一个受控形态族，不冒称覆盖所有建筑 |
| 为什么不用实测2024能耗 | 原数据条件不足；新题目采用显式控制的物理模拟，研究对象已改变 |
| 是否证明遮阳没有玻璃好 | 仅说明本研究指定的0.6m挑檐与SHGC变化的结果，不能推广至所有遮阳 |
| 是否公平比较成本 | 没有成本约束，不作成本优劣结论 |
| 是否忽略采光 | 是，照明无日光调光；仅讨论冷却需求，不作综合立面最优结论 |
| 是否从测试集泄漏 | 同情景四方案不拆分；正方形对称旋转合组；整类留出；预处理只拟合训练数据 |
| 是否通过AI得到必然结论 | 模型误差有实际测试；但当前方案选择损失退化，明确不作为成功证据 |
| 是否可以声称快速替代模拟 | 当前144次模拟已很快，未证明实际加速收益；更大的未来任务才有必要评价计算成本 |
| 实测节电量是多少 | 未估计；结果是理想系统供风冷却热需求 |
| 方法创新在哪里 | 不是新算法，是公开模型的受控跨形态验证与失败边界报告；课程应用贡献有限但明确 |

## 九 参考文献如何使用

Markarian等（2024）说明代理模型和改造优化已有先例；Thrampoulidis等（2021）说明近似改造决策也已有先例。本文不重复声称首次使用AI优化建筑。Buildings.sg用于原型来源，EnergyPlus文档用于解释理想负荷，IWEC来源用于天气追溯，scikit-learn文档用于分组验证。完整条目与链接在references.json和论文末页。

可以用这一句话介绍研究：本研究用开放办公原型建立可复现的外窗模拟数据，检验代理模型能否预测未见过的平面形态，并区分预测准确与推荐有效这两件事。
'''
(D/'操作步骤与答辩指南.md').write_text(guide,encoding='utf8')
(ROOT/'README.md').write_text('''# BPS5231 window strategy transfer study

Start with `deliverables/操作步骤与答辩指南.md`.

Submission: editable slides, three-page paper, source code and a 144-case completed simulation experiment.
Outcome is **cooling thermal demand**, not measured EUI or actual HVAC electricity.

## Reproduce analysis
```
python -m pip install -r requirements.txt
python scripts/study.py analyze
python scripts/summarize.py
```

## Reproduce simulation
Download EnergyPlus 24.2 from its official GitHub release. Original IDF and IWEC weather are included with attribution.
```
python scripts/study.py prepare
python scripts/study.py run --energyplus /absolute/path/to/energyplus --scope pilot --workers 2
python scripts/study.py run --energyplus /absolute/path/to/energyplus --scope full --workers 2
python scripts/study.py analyze
python scripts/summarize.py
python scripts/build_documents.py
```

The bundled CSV outputs allow reproduction of the ML evaluation without EnergyPlus. Model binaries, node_modules and large intermediate SQL files are excluded from the ZIP. All 144 generated IDF files and compact simulation logs are included. `scripts/build_slides.mjs` is optional and uses `@oai/artifact-tool` 2.8.84; editing the delivered PPTX requires no build tooling.

## Scope and provenance
Office template: https://github.com/City-Syntax/buildings.sg/blob/main/download/06_Office_SGP_2025_V5.idf
Weather: https://github.com/ladybug-tools/uwg/blob/master/resources/SGP_Singapore.486980_IWEC.epw
Source hashes: `results/input_hashes.json`. Engine provenance: `results/full_provenance.json`.
Generated data are research simulations under stated assumptions. Cite upstream model/data providers; no new licence is asserted over upstream assets.
''',encoding='utf8')
# Keep concise traceable error logs without packaging very large SQL/ESO files.
logs=R/'run_logs';logs.mkdir(exist_ok=True)
for p in (R/'runs').glob('*/eplusout.err'):shutil.copy2(p,logs/(p.parent.name+'.err'))
cells=[]
def md(t):cells.append({'cell_type':'markdown','metadata':{},'source':t.splitlines(True)})
def code(t):cells.append({'cell_type':'code','metadata':{},'source':t.splitlines(True),'execution_count':None,'outputs':[]})
md('# 外窗策略跨形态适用性\n本笔记本读取已完成的144次EnergyPlus模拟，并可重新执行分组回归。热量不是电耗。')
code('from pathlib import Path\nimport csv,json,sys,subprocess\nROOT=Path.cwd()\nassert (ROOT/"results/summary.json").exists(), "请从项目根目录打开笔记本"\nS=json.loads((ROOT/"results/summary.json").read_text())\nprint("Completed simulations:",S["n_cases"])\nprint("Glass better than specified shade:",S["glass_beats_shade_contexts"],"/",S["n_contexts"])')
md('## 数据与EDA\n读取全部结果，并显示同条件下四个方案比较。')
code('with (ROOT/"results/full_results.csv").open(encoding="utf-8-sig") as f:\n    rows=list(csv.DictReader(f))\nprint(rows[0])\nfrom IPython.display import Image,display\ndisplay(Image(filename=str(ROOT/"results/figures/cooling_comparison.png")))')
md('## 重新计算留出预测\n相同情景不拆分，整种形态留出为主要迁移检验；超参数固定。')
code('subprocess.run([sys.executable,str(ROOT/"scripts/study.py"),"analyze"],check=True)\nsubprocess.run([sys.executable,str(ROOT/"scripts/summarize.py")],check=True,capture_output=True)\nwith (ROOT/"results/pooled_metrics.csv").open(encoding="utf-8-sig") as f:\n    for row in csv.DictReader(f):\n        print(row["scheme"],row["model"],"MAE",round(float(row["mae"]),3))')
md('## 解释边界\n所有方案选择损失为零也不能证明AI有效：玻璃在所有情景中都优于所选挑檐，固定选择玻璃也能达到相同结果。外部形态、不同面积及运行敏感性仍待完成。')
nb={'cells':cells,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.12'}},'nbformat':4,'nbformat_minor':5}
(ROOT/'analysis.ipynb').write_text(json.dumps(nb,ensure_ascii=False,indent=2),encoding='utf8')
print('Created Chinese guide, README, notebook and compact logs.')
